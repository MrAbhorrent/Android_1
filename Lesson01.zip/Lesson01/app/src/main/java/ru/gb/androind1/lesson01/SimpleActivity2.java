package ru.gb.androind1.lesson01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SimpleActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple2);
    }
}